import shutil

archive = shutil.make_archive("photos", "zip", )